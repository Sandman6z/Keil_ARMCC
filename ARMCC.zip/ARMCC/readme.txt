#
从MDK-ARM 5.35版本后就没有了ARMCC V5.06编译器了，后装的keygen也无法破解，只能从5.35版本移植过来
此ARMCC 放到..\Keil_v5\ARM目录下即可